$(document).ready(function() {

	// Скрипт подсветки схемы
	$(".part_1").mouseenter(function() {
		$(".shape_1").animate({'opacity':'1'}, 100);
	});
	$(".part_1").mouseleave(function() {
		$(".shape_1").animate({'opacity':'0'}, 100);
	});

	$(".part_2").mouseenter(function() {
		$(".shape_2").animate({'opacity':'1'}, 100);
	});
	$(".part_2").mouseleave(function() {
		$(".shape_2").animate({'opacity':'0'}, 100);
	});

	$(".part_3").mouseenter(function() {
		$(".shape_2").animate({'opacity':'1'}, 100);
	});
	$(".part_3").mouseleave(function() {
		$(".shape_2").animate({'opacity':'0'}, 100);
	});

	$(".part_4").mouseenter(function() {
		$(".shape_2").animate({'opacity':'1'}, 100);
	});
	$(".part_4").mouseleave(function() {
		$(".shape_2").animate({'opacity':'0'}, 100);
	});

	$(".part_5").mouseenter(function() {
		$(".shape_3").animate({'opacity':'1'}, 100);
	});
	$(".part_5").mouseleave(function() {
		$(".shape_3").animate({'opacity':'0'}, 100);
	});

	$(".part_6").mouseenter(function() {
		$(".shape_5").animate({'opacity':'1'}, 100);
	});
	$(".part_6").mouseleave(function() {
		$(".shape_5").animate({'opacity':'0'}, 100);
	});

	$(".part_7").mouseenter(function() {
		$(".shape_7").animate({'opacity':'1'}, 100);
	});
	$(".part_7").mouseleave(function() {
		$(".shape_7").animate({'opacity':'0'}, 100);
	});

	$(".part_8").mouseenter(function() {
		$(".shape_6").animate({'opacity':'1'}, 100);
	});
	$(".part_8").mouseleave(function() {
		$(".shape_6").animate({'opacity':'0'}, 100);
	});

	$(".part_11").mouseenter(function() {
		$(".shape_4").animate({'opacity':'1'}, 100);
	});
	$(".part_11").mouseleave(function() {
		$(".shape_4").animate({'opacity':'0'}, 100);
	});

	$(".part_10").mouseenter(function() {
		$(".shape_8").animate({'opacity':'1'}, 100);
	});
	$(".part_10").mouseleave(function() {
		$(".shape_8").animate({'opacity':'0'}, 100);
	});

	$(".part_9").mouseenter(function() {
		$(".shape_7").animate({'opacity':'1'}, 100);
		$(".shape_6").animate({'opacity':'1'}, 100);
	});
	$(".part_9").mouseleave(function() {
		$(".shape_7").animate({'opacity':'0'}, 100);
		$(".shape_6").animate({'opacity':'0'}, 100);
	});
});