Date.prototype.addDays = function(days) {
    this.setDate(this.getDate() + parseInt(days));
    return this;
};

$(document).ready(function() {
	function getMonthName(num){
		var monthNames = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
		return monthNames[num];
	}
	var d = new Date();
	d = d.addDays(5);
	var sale_day = d.getDate();
	var new_date = sale_day.toString() + " " + getMonthName(d.getMonth()) + "!";
	var g_objects = $('.sale_date');
	g_objects.empty();
	g_objects.append(new_date);
});

$(document).ready(function() {
	// Маска телефонов
	//$('input[type="tel"]').mask('+7 (999) 999-99-99');
	$('input[type="tel"]').mask("**********?******", {placeholder: "" });

	// Лайтбокс
	$('a.gallery').colorbox({ opacity:0.9 , rel:'group1' });
	$('a.cert_gallery').colorbox({ opacity:0.9 , rel:'group2' });

	// Google map
	// function initialize() {
	//   var mapOptions = {
	//     zoom: 16,
	//     center: new google.maps.LatLng("55.762770", "37.679096")
	//   }
	//   var map = new google.maps.Map(document.getElementById('makemap_canvas'),
	//                                 mapOptions);
	//   var image = 'img/telega_contacts_office.png';
	//   var image1 = 'img/telega_contacts_back.png';
	//   var myLatLng = new google.maps.LatLng("55.762770", "37.679096");
	//   var beachMarker = new google.maps.Marker({
	//       position: myLatLng,
	//       map: map,
	//       icon: image
	//   });
	// }

	// google.maps.event.addDomListener(window, 'load', initialize);

	// Yandex maps
	ymaps.ready(init);
	var myMap;
	var myMap1

	function init(){
	    myMap = new ymaps.Map("makemap_canvas", {
	        center: [55.709885, 37.68659],
	        zoom: 13,
	        controls: ['smallMapDefaultSet']
	    });

	    myMap1 = new ymaps.Map("makemap_canvas1", {
	        center: [55.578854, 37.635054],
	        zoom: 13,
	        controls: ['smallMapDefaultSet']
	    });

	    myMap.controls.add(
			new ymaps.control.ZoomControl()
		);

		myMap1.controls.add(
			new ymaps.control.ZoomControl()
		);

		myMap.controls.add('typeSelector');
		myMap1.controls.add('typeSelector');

	    var flag_1 = new ymaps.Placemark([55.709885, 37.68659], {
	    },
	    {
	        iconLayout: 'default#image',
	        iconImageHref: 'img/telega_contacts_office.png',
	        iconImageSize: [78, 51],
	        iconImageOffset: [-20, -51]
	    });

	    var flag_2 = new ymaps.Placemark([55.578854, 37.635054], {
	    },
	    {
	        iconLayout: 'default#image',
	        iconImageHref: 'img/telega_contacts_back.png',
	        iconImageSize: [83, 51],
	        iconImageOffset: [-22, -51]
	    });
	    myMap.geoObjects.add(flag_1);
	    myMap1.geoObjects.add(flag_2);
	}


	// Валидация форм
	$( 'form[action="mail.php"]' )
		.removeAttr( 'onsubmit' )
		.find( 'input[type="submit"]' )
		.removeAttr( 'onclick' );

	$.validate({
		form : 'form[action="mail.php"]',
		validateOnBlur : true,
		showHelpOnFocus : false,
		addSuggestions : false,
		scrollToTopOnError : false,
		borderColorOnError : '#d71818',
		onSuccess : function( $form ){
			var
				name = $form.find( '[name="name"]' ).val(),
				phone = $form.find( '[name="phone"]' ).val(),
				question = $form.find( '[name="question"]' ).val(),
				data = $form.serialize();

			//  if( typeof name == 'string' && name.length < 3 ){
			//    alert( 'Имя должно состоять минимум из 3 символов.' );
			//    return false;
			//  }

			// if( typeof phone == 'string' && ( phone.length < 10 || !(/^[0-9 \(\)]*$/.test( phone )) ) ){
			//   alert( 'Телефон должен состоять минимум из 10 цифр.' );
			//   return false;
			//  }

			//  if( typeof question == 'string' && question.length < 10 ){
			//      alert( 'Вопрос должен состоять минимум из 10 символов' );
			//    return false;
			// }

			$.post( '/mail.php', data ).success(function( ajaxData ){
				var
					$iframe = $( '<iframe frameborder="0" />' ),
					$popup = $( '<div class="-popup" />' );

				$( '.popup-box .close' ).click();
				$iframe.attr( 'src', 'data:text/html;charset=utf-8,' + ajaxData );
				$popup.append( $iframe ).click(function(){
					$popup.remove();
				});

				$( document.body ).append( $popup );

				setTimeout(function(){
					$popup.fadeOut( 1200, function(){
						$popup.remove();
					});
				}, 4000 );
			});

			return false;
		}
	});

	/*
	$.validate({
		form : '#header_form',
		validateOnBlur : true,
		showHelpOnFocus : false,
		addSuggestions : false,
		scrollToTopOnError : false,
		borderColorOnError : '#d71818',
		onSuccess : function() {
			var m_data=$('#header_form').serialize();
			$.ajax({
				type: "POST",
				url: '/callback',
				data: m_data,
				success: function(result){
					window.location.href = "/thanks";
				}
			});
			return false;
		}
	});

	$.validate({
		form : '#sale_form',
		validateOnBlur : true,
		showHelpOnFocus : false,
		addSuggestions : false,
		scrollToTopOnError : false,
		borderColorOnError : '#d71818',
		onSuccess : function() {
			var m_data=$('#sale_form').serialize();
			$.ajax({
				type: "POST",
				url: '/callback',
				data: m_data,
				success: function(result){
					window.location.href = "/thanks";
				}
			});
			return false;
		}
	});

	$.validate({
		form : '#popup_1_form',
		validateOnBlur : true,
		showHelpOnFocus : false,
		addSuggestions : false,
		scrollToTopOnError : false,
		borderColorOnError : '#d71818',
		onSuccess : function() {
			var m_data=$('#popup_1_form').serialize();
			$.ajax({
				type: "POST",
				url: '/callback',
				data: m_data,
				success: function(result){
					window.location.href = "/thanks";
				}
			});
			return false;
		}
	});

	$.validate({
		form : '#popup_2_form',
		validateOnBlur : true,
		showHelpOnFocus : false,
		addSuggestions : false,
		scrollToTopOnError : false,
		borderColorOnError : '#d71818',
		onSuccess : function() {
			var m_data=$('#popup_2_form').serialize();
			$.ajax({
				type: "POST",
				url: '/callback',
				data: m_data,
				success: function(result){
					window.location.href = "/thanks";
				}
			});
			return false;
		}
	});

	$.validate({
		form : '#popup_3_form',
		validateOnBlur : true,
		showHelpOnFocus : false,
		addSuggestions : false,
		scrollToTopOnError : false,
		borderColorOnError : '#d71818',
		onSuccess : function() {
			var m_data=$('#popup_3_form').serialize();
			$.ajax({
				type: "POST",
				url: '/callback',
				data: m_data,
				success: function(result){
					window.location.href = "/thanks";
				}
			});
			return false;
		}
	});

	$.validate({
		form : '#question_form',
		validateOnBlur : true,
		showHelpOnFocus : false,
		addSuggestions : false,
		scrollToTopOnError : false,
		borderColorOnError : '#d71818',
		onSuccess : function() {
			var m_data=$('#question_form').serialize();
			$.ajax({
				type: "POST",
				url: '/callback',
				data: m_data,
				success: function(result){
					window.location.href = "/thanks";
				}
			});
			return false;
		}
	});
	*/

});